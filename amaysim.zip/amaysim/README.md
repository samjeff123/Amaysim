## My amaysim automation test suite
a simple test suite that logs into MyAmaysim and
validates that the manage settings functionality

## Getting Started
## Dependencies
Node js
Npm 
Any text editor
Cypress automation tool
Terminal

## Installing
https://docs.cypress.io/guides/getting-started/installing-cypress
1. Install cypress - execute npm init -y
2. run npx cypress open

how to run the test framework
1. Open your text editor
2. Open the extracted file
3. run npx cypress open
4. amaysim> settings management.spec.js
