/// <reference types="cypress" />
describe("Automation for MyAmaysim: managing settings", () => {
    beforeEach(() => {
        //User pre condition should be here
        // Cypress.Cookies.preserveOnce('SessionID', 'auth_cookie');
        // to prevent the broken session and to prevent the user redirecting back to the login page 
    });

    it("User can access the site",() => {
        cy.visit("https://www.amaysim.com.au/")
    });

    it("User should be able directed to the login page", () => {
        cy.get("li > .icon-link > span").contains("Account").click()
    });

    // For Error message validation
    // it("User should be able to see the error message when login in - in an empty state", () => {
    //     cy.get(".arrow-next").click()
        // cy.get(":nth-child(5) > .form-inline-message").contains("Please enter your amaysim number or email.").click({ force: true })
        // cy.get(":nth-child(6) > .form-inline-message").contains("Please enter your password to login.").click({ force: true })
    // });

    it("User should be able to add his/her login crendentials", () => {
        cy.get(":nth-child(5) > .input-icon").click()
        cy.get("#username").type("0466134574")
        cy.get("#password").type("AWqasde321")
        cy.get(":nth-child(6) > .input-icon").click()
        cy.get(".arrow-next", {timeout: 3000}).click()
    });

    it("User can navigate to the dashboard", () => {
        // To validate if the user is already in the dashboard
        // cy.wait(2000)
        cy.get("#WelcomeMessage").contains("Hey Test Rachel, how can we help?")
        cy.get(".active > span").contains("services")
        cy.get(":nth-child(6) > .input-icon").click()
    });

    it("User should be directed to the setting page", () => {
        cy.contains("Test 5636",{timeout: 3000}).click({force:true})
    });

    it("User should be able to close the modal", () => {
        cy.should('have.class', 'close-reveal-modal').contains("x").click()
    });

    it("User should be able be directed to the setting page", () => {
        cy.contains("Settings").click()
        cy.wait(3000)
    });

    it("User should be able manage/edit the sim nickname", () => {
        cy.get('[id="edit_settings_phone_label"]').contains("edit").click()
        cy.should('have.class', 'string tel optional').type("My New Sim Nickname")
        cy.should('have.class', 'button-green-action small-12 medium-7 medium-offset-1 large-offset-2 columns')
        .contains("Save").click()
    });

    it("User should be able manage/edit the Recharge Pin", () => {
        cy.get('[id="edit_settings_recharge_pin"]').contains("edit").click()
        cy.should('have.class', 'string tel optional').type("1231")
        cy.should('have.class', 'button-green-action small-12 medium-7 medium-offset-1 large-offset-2 columns')
        .contains("Save").click()
    });

    it("User should be able to modify the caller ID checkbox", () => {
        cy.get('[type="checkbox"]').should('have.id', 'my_amaysim2_setting_caller_id_out').uncheck()
    });
  
    it("User should be able to modify the call waiting checkbox", () => {
        cy.get('[type="checkbox"]').should('have.id', 'my_amaysim2_setting_caller_waiting').uncheck()
    });
  
    it("User should be able to modify the setting voicemail checkbox", () => {
        cy.get('[type="checkbox"]').should('have.id', 'my_amaysim2_setting_voice_mail').check()
    });

    it("User should be able to modify the setting usage alert checkbox", () => {
        cy.get('[type="checkbox"]').should('have.id', 'my_amaysim2_setting_usage_alert').check()
    });

    it("User should be able to modify the setting international roaming checkbox", () => {
        cy.get('[type="checkbox"]').should('have.id', 'my_amaysim2_setting_intl_roaming').uncheck()
    });

    
});